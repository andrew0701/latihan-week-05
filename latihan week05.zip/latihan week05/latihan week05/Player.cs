﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace latihan_week05
{
    internal class Player
    {
        private string playerName;
        private string playerNumber;
        private string playerPos;

        //Constructor
        public Player (string _playerName, string _playerNumber, string _playerPos)
        {
            playerName = _playerName;
            playerNumber = _playerNumber;
            playerPos = _playerPos;
        }

        // Getter (Mengambil Value Dari Variable)
        public string getPlayerName() {  return playerName; }
        public string getPlayerNumber() {  return playerNumber; }
        public string getPlayerPos() {  return playerPos; } 

        // setter (Set Value untuk Variable nya
        public void setPlayerName(string playerName) { this.playerName = playerName; }
        public void setPlayerNumber(string playerNumber) {  this.playerNumber = playerNumber; }
        public void setPlayerPos (string playerPos) { this.playerPos = playerPos; }
    }
}
