﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace latihan_week05
{
    public partial class Form1 : Form
    {
        List<Team> teamList;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            teamList = new List<Team>();
            List<Player> playerList = new List<Player>
            {
                new Player ("Edwin" , "01 " , "GK"),
                new Player ("Stanley" , "02 " , "DF"),
                new Player ("Amanda" , "03 " , "DF")
            };
            teamList.Add(new Team("UC Ceria", "Indonesia" , "Surabaya" , playerList));
            playerList = new List<Player>
            {
                new Player("Jefferson", "01 ", "GK"),
                new Player("Howie", "09 ", "FW"),
                new Player("Bernard", "05 ", "MF")
            };
            teamList.Add(new Team("UC Bahagia", "Indonesia", "Surabaya", playerList));
            foreach (Team team in teamList)
            {
                string teamName = team.getTeamName();
                string teamCountry = team.getTeamCountry();
                playerList = team.getPlayerList();
                string players = "";
                foreach (Player player in playerList)
                {
                    players += player.getPlayerName() + ", ";
                }
                MessageBox.Show(teamName + " is a " + teamCountry, " team with " + playerList + " members.");
            }
        }
    }
}
